Download more flags at https://github.com/gosquared/flags/tree/master/flags/flags/flat
