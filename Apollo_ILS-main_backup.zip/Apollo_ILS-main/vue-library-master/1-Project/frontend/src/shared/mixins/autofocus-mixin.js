export default {
  mounted() {
    if (this.$refs.focus) {
      this.$refs.focus.focus();
    }
  },
};
