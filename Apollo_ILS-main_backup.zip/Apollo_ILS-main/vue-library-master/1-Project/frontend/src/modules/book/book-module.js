import routes from '@/modules/book/book-routes';
import store from '@/modules/book/book-store';

export default {
  routes,
  store,
};
