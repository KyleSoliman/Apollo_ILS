const backendUrl = null;

export default {
  backendUrl,
};
